"use strict";

/* =====================================================
   ALMEF
   COMPLETE JAVASCRIPT APPLICATION
   PART 1: CONFIGURATION AND APPLICATION STATE
   LINES 1–100
===================================================== */

/* =====================================================
   1. APPLICATION CONFIGURATION
===================================================== */

const ALMEF_CONFIG = {
    name: "Almef",
    version: "1.0.0",
    description: "Your personal AI assistant",

    /*
       Replace this with your backend endpoint
       when we connect the AI service.
    */

    apiUrl: "http://127.0.0.1:8000/chat",

    /*
       Maximum characters allowed in a message.
    */

    maxMessageLength: 10000,

    /*
       Maximum number of saved conversations.
    */

    maxConversations: 100,

    /*
       Local storage keys.
    */

    storageKeys: {
        theme: "almef_theme",
        conversations: "almef_conversations",
        activeConversation: "almef_active_conversation"
    }
};

/* =====================================================
   2. APPLICATION STATE
===================================================== */

const AlmefState = {
    currentView: "chat",

    sidebarOpen: false,

    isLoading: false,

    isRecording: false,

    currentTheme: "dark",

    activeConversationId: null,

    conversations: [],

    attachedImage: null,

    recognition: null,

    abortController: null
};

/* =====================================================
   3. DOM ELEMENT REFERENCES
===================================================== */

const AlmefDOM = {
    /*
       Main application elements.
    */

    body: document.body,

    sidebar: document.getElementById("sidebar"),

    sidebarOverlay:
        document.getElementById("sidebarOverlay"),

    mainContent:
        document.querySelector(".main-content"),

    /*
       Navigation elements.
    */

    openSidebar:
        document.getElementById("openSidebar"),

    closeSidebar:
        document.getElementById("closeSidebar"),

    newChat:
        document.getElementById("newChat"),

    navItems:
        document.querySelectorAll(".nav-item"),

    /*
       Chat elements.
    */

    chatView:
        document.getElementById("chatView"),

    welcomeContainer:
        document.getElementById("welcomeContainer"),

    messagesContainer:
        document.getElementById("messagesContainer"),

    /*
       Message composer elements.
    */

    messageInput:
        document.getElementById("messageInput"),

    sendButton:
        document.getElementById("sendButton"),

    voiceButton:
        document.getElementById("voiceButton"),

    attachButton:
        document.getElementById("attachButton"),

    imageInput:
        document.getElementById("imageInput"),

    attachmentPreview:
        document.getElementById("attachmentPreview"),

    /*
       Theme elements.
    */

    themeToggle:
        document.getElementById("themeToggle"),

    themeIcon:
        document.getElementById("themeIcon"),

    themeLabel:
        document.getElementById("themeLabel"),

    /*
       About dialog elements.
    */

    aboutButton:
        document.getElementById("aboutButton"),

    aboutDialog:
        document.getElementById("aboutDialog"),

    closeAbout:
        document.getElementById("closeAbout"),

    /*
       Additional controls.
    */

    shareButton:
        document.getElementById("shareButton")
};

/* =====================================================
   4. APPLICATION UTILITIES
===================================================== */

/*
   Generate a unique conversation identifier.
*/

function generateConversationId() {
    return (
        "conversation_" +
        Date.now() +
        "_" +
        Math.random().toString(36).slice(2, 9)
    );
}

/*
   Get the current date and time.
*/

function getCurrentTimestamp() {
    return new Date().toISOString();
}

/*
   Safely read a value from local storage.
*/

function readStorage(key, fallback = null) {
    try {
        const value = localStorage.getItem(key);

        return value === null
            ? fallback
            : value;

    } catch (error) {
        console.warn(
            "Almef: Could not read local storage.",
            error
        );

        return fallback;
    }
}

/*
   Safely save a value to local storage.
*/

function writeStorage(key, value) {
    try {
        localStorage.setItem(key, value);

        return true;

    } catch (error) {
        console.warn(
            "Almef: Could not save to local storage.",
            error
        );

        return false;
    }
}

/*
   Safely remove a value from local storage.
*/

function removeStorage(key) {
    try {
        localStorage.removeItem(key);

        return true;

    } catch (error) {
        console.warn(
            "Almef: Could not remove local storage.",
            error
        );

        return false;
    }
}

/*
   Check whether an element exists.
*/

function elementExists(element) {
    return element instanceof HTMLElement;
}

/*
   Check whether the device is using a small screen.
*/

function isMobileScreen() {
    return window.matchMedia(
        "(max-width: 700px)"
    ).matches;
}

/*
   Display a message in the browser console.
*/

function almefLog(message, data = null) {
    if (data !== null) {
        console.log(
            "[Almef]",
            message,
            data
        );

        return;
    }

    console.log("[Almef]", message);
}

/* =====================================================
   END OF PART 1
   LINES 1–100
===================================================== */
/* =====================================================
   ALMEF JAVASCRIPT
   PART 2: SIDEBAR AND NAVIGATION
   LINES 101–200
===================================================== */

/* =====================================================
   5. SIDEBAR CONTROLS
===================================================== */

/*
   Open the application sidebar.
*/

function openAlmefSidebar() {
    const sidebar = AlmefDOM.sidebar;
    const overlay = AlmefDOM.sidebarOverlay;

    if (!elementExists(sidebar)) {
        return;
    }

    sidebar.classList.add("open");

    if (elementExists(overlay)) {
        overlay.classList.add("visible");
        overlay.setAttribute("aria-hidden", "false");
    }

    AlmefState.sidebarOpen = true;

    document.body.classList.add("sidebar-open");
}

/*
   Close the application sidebar.
*/

function closeAlmefSidebar() {
    const sidebar = AlmefDOM.sidebar;
    const overlay = AlmefDOM.sidebarOverlay;

    if (elementExists(sidebar)) {
        sidebar.classList.remove("open");
    }

    if (elementExists(overlay)) {
        overlay.classList.remove("visible");
        overlay.setAttribute("aria-hidden", "true");
    }

    AlmefState.sidebarOpen = false;

    document.body.classList.remove("sidebar-open");
}

/*
   Toggle the sidebar between open and closed.
*/

function toggleAlmefSidebar() {
    if (AlmefState.sidebarOpen) {
        closeAlmefSidebar();
    } else {
        openAlmefSidebar();
    }
}

/*
   Automatically close the sidebar on mobile.
*/

function closeSidebarOnMobile() {
    if (isMobileScreen()) {
        closeAlmefSidebar();
    }
}

/*
   Update sidebar accessibility information.
*/

function updateSidebarAccessibility() {
    const button = AlmefDOM.openSidebar;

    if (!elementExists(button)) {
        return;
    }

    button.setAttribute(
        "aria-expanded",
        String(AlmefState.sidebarOpen)
    );
}

/* =====================================================
   6. VIEW NAVIGATION
===================================================== */

/*
   Find a view using its data-view attribute.
*/

function findAlmefView(viewName) {
    return document.querySelector(
        `[data-page="${viewName}"]`
    );
}

/*
   Set the currently selected navigation item.
*/

function setActiveNavigation(viewName) {
    AlmefDOM.navItems.forEach((item) => {
        const itemView = item.dataset.view;

        item.classList.toggle(
            "active",
            itemView === viewName
        );

        if (itemView === viewName) {
            item.setAttribute("aria-current", "page");
        } else {
            item.removeAttribute("aria-current");
        }
    });
}

/*
   Switch the application to another view.
*/

function switchAlmefView(viewName) {
    const allowedViews = [
        "chat",
        "history",
        "explore"
    ];

    if (!allowedViews.includes(viewName)) {
        console.warn("Almef: Unknown view:", viewName);
        return;
    }

    AlmefState.currentView = viewName;

    setActiveNavigation(viewName);

    document.body.dataset.currentView = viewName;

    const chatView = AlmefDOM.chatView;

    if (elementExists(chatView)) {
        chatView.hidden = viewName !== "chat";
    }

    const historyView = document.getElementById(
        "historyView"
    );

    if (elementExists(historyView)) {
        historyView.hidden = viewName !== "history";
    }

    const exploreView = document.getElementById(
        "exploreView"
    );

    if (elementExists(exploreView)) {
        exploreView.hidden = viewName !== "explore";
    }

    closeSidebarOnMobile();

    almefLog("View changed to " + viewName);
}

/* =====================================================
   7. NAVIGATION ACTIONS
===================================================== */

/*
   Handle a navigation item click.
*/

function handleNavigationClick(event) {
    const item = event.currentTarget;

    if (!(item instanceof HTMLElement)) {
        return;
    }

    const viewName = item.dataset.view;

    if (viewName) {
        switchAlmefView(viewName);
        return;
    }

    const prompt = item.dataset.prompt;

    if (prompt) {
        switchAlmefView("chat");

        if (typeof setComposerText === "function") {
            setComposerText(prompt);
        }
    }
}

/*
   Navigate to the chat view.
*/

function openChatView() {
    switchAlmefView("chat");

    if (elementExists(AlmefDOM.messageInput)) {
        AlmefDOM.messageInput.focus();
    }
}

/*
   Navigate to conversation history.
*/

function openHistoryView() {
    switchAlmefView("history");

    if (typeof renderConversationHistory === "function") {
        renderConversationHistory();
    }
}

/*
   Navigate to the explore view.
*/

function openExploreView() {
    switchAlmefView("explore");
}

/* =====================================================
   END OF PART 2
   LINES 101–200
===================================================== */
/* =====================================================
   ALMEF JAVASCRIPT
   PART 3: NEW CHATS AND MESSAGE HANDLING
   LINES 201–300
===================================================== */

/* =====================================================
   8. CONVERSATION MANAGEMENT
===================================================== */

/*
   Create a new conversation object.
*/

function createConversation() {
    const conversation = {
        id: generateConversationId(),
        title: "New chat",
        messages: [],
        createdAt: getCurrentTimestamp(),
        updatedAt: getCurrentTimestamp()
    };

    AlmefState.conversations.unshift(conversation);

    AlmefState.activeConversationId = conversation.id;

    saveConversations();

    return conversation;
}

/*
   Get the currently active conversation.
*/

function getActiveConversation() {
    return AlmefState.conversations.find(
        (conversation) =>
            conversation.id ===
            AlmefState.activeConversationId
    ) || null;
}

/*
   Start a fresh conversation.
*/

function startNewChat() {
    if (AlmefState.isLoading) {
        cancelCurrentRequest();
    }

    const conversation = createConversation();

    AlmefState.attachedImage = null;

    clearAttachmentPreview();

    clearChatMessages();

    showWelcomeScreen();

    switchAlmefView("chat");

    updateConversationTitle(conversation.title);

    closeSidebarOnMobile();

    if (elementExists(AlmefDOM.messageInput)) {
        AlmefDOM.messageInput.value = "";
        AlmefDOM.messageInput.focus();
    }

    almefLog("New conversation created.");
}

/*
   Update the conversation title.
*/

function updateConversationTitle(title) {
    const titleElement = document.getElementById(
        "conversationTitle"
    );

    if (!elementExists(titleElement)) {
        return;
    }

    titleElement.textContent = title || "New chat";
}

/* =====================================================
   9. MESSAGE DATA
===================================================== */

/*
   Create a message object.
*/

function createMessage(role, content, extras = {}) {
    return {
        id: generateConversationId(),
        role: role,
        content: String(content ?? ""),
        timestamp: getCurrentTimestamp(),
        ...extras
    };
}

/*
   Add a message to the active conversation.
*/

function addMessageToConversation(role, content, extras = {}) {
    let conversation = getActiveConversation();

    if (!conversation) {
        conversation = createConversation();
    }

    const message = createMessage(
        role,
        content,
        extras
    );

    conversation.messages.push(message);

    conversation.updatedAt = getCurrentTimestamp();

    if (
        conversation.title === "New chat" &&
        role === "user"
    ) {
        conversation.title = createConversationTitle(content);

        updateConversationTitle(conversation.title);
    }

    saveConversations();

    return message;
}

/*
   Generate a short title from the first message.
*/

function createConversationTitle(content) {
    const cleaned = String(content)
        .replace(/\s+/g, " ")
        .trim();

    if (!cleaned) {
        return "New chat";
    }

    const maximumLength = 36;

    if (cleaned.length <= maximumLength) {
        return cleaned;
    }

    return cleaned.slice(0, maximumLength - 3) + "...";
}

/* =====================================================
   10. MESSAGE DISPLAY
===================================================== */

/*
   Remove all messages from the visible chat.
*/

function clearChatMessages() {
    const container = AlmefDOM.messagesContainer;

    if (!elementExists(container)) {
        return;
    }

    container.replaceChildren();
}

/*
   Display the welcome screen.
*/

function showWelcomeScreen() {
    if (elementExists(AlmefDOM.welcomeContainer)) {
        AlmefDOM.welcomeContainer.hidden = false;
    }

    if (elementExists(AlmefDOM.messagesContainer)) {
        AlmefDOM.messagesContainer.hidden = true;
    }
}

/*
   Hide the welcome screen.
*/

function hideWelcomeScreen() {
    if (elementExists(AlmefDOM.welcomeContainer)) {
        AlmefDOM.welcomeContainer.hidden = true;
    }

    if (elementExists(AlmefDOM.messagesContainer)) {
        AlmefDOM.messagesContainer.hidden = false;
    }
}

/*
   Create a safe message bubble.
*/

function createMessageElement(message) {
    const article = document.createElement("article");

    article.className = "message";

    article.classList.add(
        message.role === "user"
            ? "user-message"
            : "assistant-message"
    );

    article.dataset.messageId = message.id;

    const bubble = document.createElement("div");

    bubble.className = "message-bubble";

    const content = document.createElement("div");

    content.className = "message-content";

    content.textContent = message.content;

    bubble.appendChild(content);

    article.appendChild(bubble);

    return article;
}

/*
   Render a message in the chat.
*/

function renderMessage(message) {
    const container = AlmefDOM.messagesContainer;

    if (!elementExists(container)) {
        console.error("Almef: Messages container is missing.");
        return null;
    }

    hideWelcomeScreen();

    const messageElement = createMessageElement(message);

    container.appendChild(messageElement);

    scrollChatToBottom();

    return messageElement;
}

/*
   Scroll the chat to the latest message.
*/

function scrollChatToBottom() {
    const container = AlmefDOM.messagesContainer;

    if (!elementExists(container)) {
        return;
    }

    requestAnimationFrame(() => {
        container.scrollTop = container.scrollHeight;
    });
}

/* =====================================================
   END OF PART 3
   LINES 201–300
===================================================== */
/* =====================================================
   ALMEF JAVASCRIPT
   PART 4: COMPOSER AND KEYBOARD CONTROLS
   LINES 301–400
===================================================== */

/* =====================================================
   11. MESSAGE COMPOSER
===================================================== */

/*
   Update the message composer text.
*/

function setComposerText(text) {
    const input = AlmefDOM.messageInput;

    if (!elementExists(input)) {
        return;
    }

    input.value = String(text ?? "");

    resizeMessageInput();

    updateSendButtonState();

    input.focus();
}

/*
   Get the current composer text.
*/

function getComposerText() {
    const input = AlmefDOM.messageInput;

    if (!elementExists(input)) {
        return "";
    }

    return input.value.trim();
}

/*
   Clear the message composer.
*/

function clearMessageComposer() {
    const input = AlmefDOM.messageInput;

    if (!elementExists(input)) {
        return;
    }

    input.value = "";

    resizeMessageInput();

    updateSendButtonState();
}

/*
   Resize the text area to fit its content.
*/

function resizeMessageInput() {
    const input = AlmefDOM.messageInput;

    if (!elementExists(input)) {
        return;
    }

    input.style.height = "auto";

    const maximumHeight = 180;

    input.style.height =
        Math.min(input.scrollHeight, maximumHeight) + "px";

    input.style.overflowY =
        input.scrollHeight > maximumHeight
            ? "auto"
            : "hidden";
}

/*
   Enable or disable the send button.
*/

function updateSendButtonState() {
    const button = AlmefDOM.sendButton;
    const input = AlmefDOM.messageInput;

    if (!elementExists(button) || !elementExists(input)) {
        return;
    }

    const hasText = input.value.trim().length > 0;

    const hasImage = Boolean(AlmefState.attachedImage);

    button.disabled =
        !hasText && !hasImage && !AlmefState.isLoading;
}

/* =====================================================
   12. KEYBOARD INTERACTIONS
===================================================== */

/*
   Handle Enter and Shift+Enter.
*/

function handleComposerKeydown(event) {
    if (event.key !== "Enter") {
        return;
    }

    if (event.shiftKey || event.isComposing) {
        return;
    }

    event.preventDefault();

    submitCurrentMessage();
}

/*
   Handle changes to the composer.
*/

function handleComposerInput() {
    resizeMessageInput();

    updateSendButtonState();
}

/*
   Handle keyboard shortcuts.
*/

function handleAlmefKeyboardShortcuts(event) {
    const target = event.target;

    const typingInField =
        target instanceof HTMLInputElement ||
        target instanceof HTMLTextAreaElement ||
        target instanceof HTMLSelectElement ||
        (target instanceof HTMLElement && target.isContentEditable);

    /*
       Escape closes the mobile sidebar or dialog.
    */

    if (event.key === "Escape") {
        if (AlmefState.sidebarOpen) {
            closeAlmefSidebar();
        }

        if (
            elementExists(AlmefDOM.aboutDialog) &&
            AlmefDOM.aboutDialog.open
        ) {
            AlmefDOM.aboutDialog.close();
        }

        return;
    }

    /*
       Ctrl/Cmd + K starts a new conversation.
    */

    if (
        (event.ctrlKey || event.metaKey) &&
        event.key.toLowerCase() === "k"
    ) {
        event.preventDefault();

        startNewChat();

        return;
    }

    /*
       Do not intercept normal typing shortcuts.
    */

    if (typingInField) {
        return;
    }

    /*
       "/" focuses the message composer.
    */

    if (event.key === "/") {
        event.preventDefault();

        if (elementExists(AlmefDOM.messageInput)) {
            AlmefDOM.messageInput.focus();
        }
    }
}

/* =====================================================
   13. MESSAGE SUBMISSION
===================================================== */

/*
   Submit the current message.
*/

function submitCurrentMessage() {
    const text = getComposerText();

    const image = AlmefState.attachedImage;

    if (!text && !image) {
        return;
    }

    if (AlmefState.isLoading) {
        return;
    }

    sendUserMessage(text, image);
}

/*
   Prepare and send a user message.
   The backend request is implemented in Part 8.
*/

async function sendUserMessage(text, image = null) {
    const cleanText = String(text ?? "").trim();

    if (!cleanText && !image) {
        return;
    }

    if (cleanText.length > ALMEF_CONFIG.maxMessageLength) {
        showAlmefNotice(
            "Your message is too long. Please shorten it."
        );

        return;
    }

    const messageContent = cleanText ||
        (image ? "Please describe this image." : "");

    const extras = image
        ? { image: image }
        : {};

    const message = addMessageToConversation(
        "user",
        messageContent,
        extras
    );

    renderMessage(message);

    clearMessageComposer();

    AlmefState.attachedImage = null;

    clearAttachmentPreview();

    switchAlmefView("chat");

    await requestAssistantResponse(message);
}

/* =====================================================
   END OF PART 4
   LINES 301–400
===================================================== */
/* =====================================================
   ALMEF JAVASCRIPT
   PART 5: CHAT HISTORY AND STORAGE
   LINES 401–500
===================================================== */

/* =====================================================
   14. SAVE CONVERSATIONS
===================================================== */

/*
   Save conversations to local storage.
*/

function saveConversations() {
    const key = ALMEF_CONFIG.storageKeys.conversations;

    const conversations = AlmefState.conversations.slice(
        0,
        ALMEF_CONFIG.maxConversations
    );

    const saved = writeStorage(
        key,
        JSON.stringify(conversations)
    );

    writeStorage(
        ALMEF_CONFIG.storageKeys.activeConversation,
        AlmefState.activeConversationId || ""
    );

    return saved;
}

/*
   Load conversations from local storage.
*/

function loadConversations() {
    const stored = readStorage(
        ALMEF_CONFIG.storageKeys.conversations,
        "[]"
    );

    try {
        const parsed = JSON.parse(stored);

        if (!Array.isArray(parsed)) {
            AlmefState.conversations = [];
            return;
        }

        AlmefState.conversations = parsed.filter(
            (conversation) =>
                conversation &&
                typeof conversation.id === "string" &&
                Array.isArray(conversation.messages)
        );

    } catch (error) {
        console.warn(
            "Almef: Saved conversations could not be loaded.",
            error
        );

        AlmefState.conversations = [];
    }

    const savedActiveId = readStorage(
        ALMEF_CONFIG.storageKeys.activeConversation,
        ""
    );

    const activeExists = AlmefState.conversations.some(
        (conversation) => conversation.id === savedActiveId
    );

    AlmefState.activeConversationId = activeExists
        ? savedActiveId
        : null;
}

/*
   Find a conversation by its identifier.
*/

function findConversationById(conversationId) {
    return AlmefState.conversations.find(
        (conversation) => conversation.id === conversationId
    ) || null;
}

/* =====================================================
   15. RESTORE CONVERSATIONS
===================================================== */

/*
   Open an existing conversation.
*/

function openConversation(conversationId) {
    const conversation = findConversationById(
        conversationId
    );

    if (!conversation) {
        showAlmefNotice("This conversation could not be found.");
        return;
    }

    AlmefState.activeConversationId = conversation.id;

    writeStorage(
        ALMEF_CONFIG.storageKeys.activeConversation,
        conversation.id
    );

    clearChatMessages();

    if (conversation.messages.length === 0) {
        showWelcomeScreen();
    } else {
        conversation.messages.forEach((message) => {
            renderMessage(message);
        });
    }

    updateConversationTitle(conversation.title);

    switchAlmefView("chat");

    closeSidebarOnMobile();

    almefLog("Conversation opened:", conversation.id);
}

/*
   Reopen the most recently active conversation.
*/

function restoreActiveConversation() {
    const conversation = getActiveConversation();

    if (!conversation) {
        showWelcomeScreen();
        return;
    }

    if (conversation.messages.length === 0) {
        showWelcomeScreen();
        return;
    }

    clearChatMessages();

    conversation.messages.forEach((message) => {
        renderMessage(message);
    });

    updateConversationTitle(conversation.title);
}

/* =====================================================
   16. HISTORY LIST
===================================================== */

/*
   Create a history list item.
*/

function createHistoryItem(conversation) {
    const item = document.createElement("button");

    item.type = "button";
    item.className = "history-item";
    item.dataset.conversationId = conversation.id;

    const title = document.createElement("span");

    title.className = "history-item-title";
    title.textContent = conversation.title || "New chat";

    const date = document.createElement("span");

    date.className = "history-item-date";

    const parsedDate = new Date(
        conversation.updatedAt || conversation.createdAt
    );

    date.textContent = Number.isNaN(parsedDate.getTime())
        ? ""
        : parsedDate.toLocaleDateString();

    item.append(title, date);

    item.addEventListener("click", () => {
        openConversation(conversation.id);
    });

    return item;
}

/*
   Render all saved conversations.
*/

function renderConversationHistory() {
    const container = document.getElementById(
        "historyList"
    );

    if (!elementExists(container)) {
        return;
    }

    container.replaceChildren();

    if (AlmefState.conversations.length === 0) {
        const empty = document.createElement("p");

        empty.className = "history-empty";
        empty.textContent = "Your conversations will appear here.";

        container.appendChild(empty);

        return;
    }

    const sorted = [...AlmefState.conversations].sort(
        (first, second) =>
            new Date(second.updatedAt || second.createdAt) -
            new Date(first.updatedAt || first.createdAt)
    );

    sorted.forEach((conversation) => {
        container.appendChild(
            createHistoryItem(conversation)
        );
    });
}

/* =====================================================
   17. DELETE CONVERSATIONS
===================================================== */

/*
   Delete one saved conversation.
*/

function deleteConversation(conversationId) {
    const conversation = findConversationById(
        conversationId
    );

    if (!conversation) {
        return false;
    }

    AlmefState.conversations =
        AlmefState.conversations.filter(
            (item) => item.id !== conversationId
        );

    if (AlmefState.activeConversationId === conversationId) {
        AlmefState.activeConversationId = null;

        clearChatMessages();

        showWelcomeScreen();

        updateConversationTitle("New chat");
    }

    saveConversations();

    renderConversationHistory();

    return true;
}

/* =====================================================
   END OF PART 5
   LINES 401–500
===================================================== */
/* =====================================================
   ALMEF JAVASCRIPT
   PART 6: THEMES AND APPLICATION SETTINGS
   LINES 501–600
===================================================== */

/* =====================================================
   18. THEME MANAGEMENT
===================================================== */

/*
   Apply a theme to the application.
*/

function applyAlmefTheme(theme) {
    const validThemes = ["dark", "light"];

    if (!validThemes.includes(theme)) {
        theme = "dark";
    }

    AlmefState.currentTheme = theme;

    document.body.classList.toggle(
        "light-theme",
        theme === "light"
    );

    document.documentElement.dataset.theme = theme;

    updateThemeControls();

    writeStorage(
        ALMEF_CONFIG.storageKeys.theme,
        theme
    );

    almefLog("Theme applied:", theme);
}

/*
   Toggle between dark and light themes.
*/

function toggleAlmefTheme() {
    const nextTheme =
        AlmefState.currentTheme === "dark"
            ? "light"
            : "dark";

    applyAlmefTheme(nextTheme);
}

/*
   Load the saved theme preference.
*/

function loadAlmefTheme() {
    const savedTheme = readStorage(
        ALMEF_CONFIG.storageKeys.theme,
        "dark"
    );

    applyAlmefTheme(savedTheme);
}

/*
   Update the theme button and its labels.
*/

function updateThemeControls() {
    const isLight = AlmefState.currentTheme === "light";

    if (elementExists(AlmefDOM.themeIcon)) {
        AlmefDOM.themeIcon.textContent =
            isLight ? "☀️" : "🌙";
    }

    if (elementExists(AlmefDOM.themeLabel)) {
        AlmefDOM.themeLabel.textContent =
            isLight ? "Light mode" : "Dark mode";
    }

    if (elementExists(AlmefDOM.themeToggle)) {
        AlmefDOM.themeToggle.setAttribute(
            "aria-label",
            isLight ? "Switch to dark mode" : "Switch to light mode"
        );

        AlmefDOM.themeToggle.setAttribute(
            "aria-pressed",
            String(isLight)
        );
    }
}

/* =====================================================
   19. APPLICATION PREFERENCES
===================================================== */

/*
   Return the current application settings.
*/

function getAlmefSettings() {
    return {
        theme: AlmefState.currentTheme,
        version: ALMEF_CONFIG.version,
        conversationCount: AlmefState.conversations.length,
        activeConversationId: AlmefState.activeConversationId
    };
}

/*
   Reset the application theme.
*/

function resetAlmefTheme() {
    applyAlmefTheme("dark");
}

/*
   Update the browser tab title.
*/

function updateBrowserTitle() {
    document.title = "Almef — Your AI Assistant";
}

/*
   Update document language and accessibility metadata.
*/

function configureDocumentMetadata() {
    if (!document.documentElement.lang) {
        document.documentElement.lang = "en";
    }

    document.documentElement.setAttribute(
        "data-app",
        "almef"
    );
}

/* =====================================================
   20. ABOUT DIALOG
===================================================== */

/*
   Open the About dialog.
*/

function openAboutDialog() {
    const dialog = AlmefDOM.aboutDialog;

    if (!elementExists(dialog)) {
        showAlmefNotice(
            "About information is not available."
        );

        return;
    }

    if (typeof dialog.showModal === "function") {
        dialog.showModal();
    } else {
        dialog.setAttribute("open", "");
    }
}

/*
   Close the About dialog.
*/

function closeAboutDialog() {
    const dialog = AlmefDOM.aboutDialog;

    if (!elementExists(dialog)) {
        return;
    }

    if (
        typeof dialog.close === "function" &&
        dialog.open
    ) {
        dialog.close();
    } else {
        dialog.removeAttribute("open");
    }
}

/*
   Close the dialog when clicking outside its content.
*/

function handleAboutDialogClick(event) {
    const dialog = AlmefDOM.aboutDialog;

    if (!elementExists(dialog)) {
        return;
    }

    if (event.target === dialog) {
        closeAboutDialog();
    }
}

/* =====================================================
   21. SYSTEM THEME INFORMATION
===================================================== */

/*
   Check the operating system's preferred theme.
*/

function getSystemPreferredTheme() {
    if (
        window.matchMedia &&
        window.matchMedia("(prefers-color-scheme: light)").matches
    ) {
        return "light";
    }

    return "dark";
}

/*
   Initialize the theme from saved preferences.
*/

function initializeAlmefTheme() {
    const savedTheme = readStorage(
        ALMEF_CONFIG.storageKeys.theme,
        null
    );

    applyAlmefTheme(
        savedTheme || getSystemPreferredTheme()
    );
}

/* =====================================================
   END OF PART 6
   LINES 501–600
===================================================== */
/* =====================================================
   ALMEF JAVASCRIPT
   PART 7: VOICE INPUT AND IMAGE ATTACHMENTS
   LINES 601–700
===================================================== */

/* =====================================================
   22. VOICE INPUT SUPPORT
===================================================== */

/*
   Check whether browser speech recognition is supported.
*/

function isVoiceInputSupported() {
    return Boolean(
        window.SpeechRecognition ||
        window.webkitSpeechRecognition
    );
}

/*
   Display a notice when voice input is unavailable.
*/

function notifyVoiceUnavailable() {
    showAlmefNotice(
        "Voice input is not supported by this browser."
    );
}

/*
   Initialize browser speech recognition.
*/

function initializeVoiceRecognition() {
    const SpeechRecognition =
        window.SpeechRecognition ||
        window.webkitSpeechRecognition;

    if (!SpeechRecognition) {
        return null;
    }

    const recognition = new SpeechRecognition();

    recognition.lang = navigator.language || "en-US";

    recognition.continuous = false;

    recognition.interimResults = true;

    recognition.maxAlternatives = 1;

    recognition.onstart = () => {
        AlmefState.isRecording = true;

        updateVoiceButtonState();
    };

    recognition.onresult = (event) => {
        let transcript = "";

        for (
            let index = event.resultIndex;
            index < event.results.length;
            index++
        ) {
            transcript += event.results[index][0].transcript;
        }

        setComposerText(transcript);
    };

    recognition.onerror = (event) => {
        console.warn(
            "Almef voice input error:",
            event.error
        );

        showAlmefNotice(
            "Voice input encountered a problem."
        );
    };

    recognition.onend = () => {
        AlmefState.isRecording = false;

        updateVoiceButtonState();
    };

    return recognition;
}

/*
   Start or stop voice recognition.
*/

function toggleVoiceInput() {
    if (!isVoiceInputSupported()) {
        notifyVoiceUnavailable();
        return;
    }

    if (!AlmefState.recognition) {
        AlmefState.recognition =
            initializeVoiceRecognition();
    }

    const recognition = AlmefState.recognition;

    if (!recognition) {
        notifyVoiceUnavailable();
        return;
    }

    if (AlmefState.isRecording) {
        recognition.stop();
        return;
    }

    try {
        recognition.start();
    } catch (error) {
        console.warn(
            "Almef could not start voice input:",
            error
        );

        showAlmefNotice(
            "Please try voice input again."
        );
    }
}

/*
   Update the voice button appearance.
*/

function updateVoiceButtonState() {
    const button = AlmefDOM.voiceButton;

    if (!elementExists(button)) {
        return;
    }

    button.classList.toggle(
        "recording",
        AlmefState.isRecording
    );

    button.setAttribute(
        "aria-pressed",
        String(AlmefState.isRecording)
    );

    button.setAttribute(
        "aria-label",
        AlmefState.isRecording
            ? "Stop voice recording"
            : "Start voice input"
    );
}

/* =====================================================
   23. IMAGE ATTACHMENTS
===================================================== */

/*
   Open the image picker.
*/

function openImagePicker() {
    if (elementExists(AlmefDOM.imageInput)) {
        AlmefDOM.imageInput.click();
    }
}

/*
   Validate and read an image file.
*/

function handleImageSelection(event) {
    const file = event.target.files?.[0];

    if (!file) {
        return;
    }

    if (!file.type.startsWith("image/")) {
        showAlmefNotice(
            "Please select a valid image file."
        );

        event.target.value = "";
        return;
    }

    const maximumSize = 5 * 1024 * 1024;

    if (file.size > maximumSize) {
        showAlmefNotice(
            "The image must be smaller than 5 MB."
        );

        event.target.value = "";
        return;
    }

    const reader = new FileReader();

    reader.onload = () => {
        if (typeof reader.result !== "string") {
            showAlmefNotice(
                "The selected image could not be loaded."
            );

            return;
        }

        AlmefState.attachedImage = {
            name: file.name,
            type: file.type,
            dataUrl: reader.result
        };

        renderAttachmentPreview();

        updateSendButtonState();
    };

    reader.onerror = () => {
        showAlmefNotice(
            "Unable to read the selected image."
        );
    };

    reader.readAsDataURL(file);
}

/* =====================================================
   24. ATTACHMENT PREVIEW
===================================================== */

/*
   Display the selected image preview.
*/

function renderAttachmentPreview() {
    const container = AlmefDOM.attachmentPreview;

    if (!elementExists(container)) {
        return;
    }

    container.replaceChildren();

    const image = AlmefState.attachedImage;

    if (!image) {
        container.hidden = true;
        return;
    }

    const preview = document.createElement("img");

    preview.src = image.dataUrl;

    preview.alt = "Selected image preview";

    preview.className = "attachment-thumbnail";

    const name = document.createElement("span");

    name.className = "attachment-name";

    name.textContent = image.name;

    const removeButton = document.createElement("button");

    removeButton.type = "button";

    removeButton.textContent = "×";

    removeButton.setAttribute(
        "aria-label",
        "Remove attached image"
    );

    removeButton.addEventListener(
        "click",
        clearAttachmentPreview
    );

    container.append(preview, name, removeButton);

    container.hidden = false;
}

/*
   Remove the selected image.
*/

function clearAttachmentPreview() {
    AlmefState.attachedImage = null;

    const container = AlmefDOM.attachmentPreview;

    if (elementExists(container)) {
        container.replaceChildren();
        container.hidden = true;
    }

    if (elementExists(AlmefDOM.imageInput)) {
        AlmefDOM.imageInput.value = "";
    }

    updateSendButtonState();
}

/* =====================================================
   END OF PART 7
   LINES 601–700
===================================================== */
/* =====================================================
   ALMEF JAVASCRIPT
   PART 8: AI BACKEND CONNECTION
   LINES 701–800
===================================================== */

/* =====================================================
   25. BACKEND CONFIGURATION
===================================================== */

/*
   Return the configured API endpoint.
*/

function getAlmefApiUrl() {
    return ALMEF_CONFIG.apiUrl;
}

/*
   Check whether the browser can make network requests.
*/

function isNetworkAvailable() {
    return navigator.onLine;
}

/*
   Create request headers.
*/

function createApiHeaders() {
    return {
        "Content-Type": "application/json",
        "Accept": "application/json"
    };
}

/*
   Build the request body.
*/

function createApiPayload(message) {
    const conversation = getActiveConversation();

    const previousMessages = conversation
        ? conversation.messages.slice(-20)
        : [];

    return {
        message: message.content,
        conversation_id: AlmefState.activeConversationId,
        history: previousMessages.map((item) => ({
            role: item.role,
            content: item.content
        })),
        image: message.image?.dataUrl || null
    };
}

/* =====================================================
   26. LOADING INDICATOR
===================================================== */

/*
   Create an assistant typing indicator.
*/

function showTypingIndicator() {
    const container = AlmefDOM.messagesContainer;

    if (!elementExists(container)) {
        return null;
    }

    hideWelcomeScreen();

    const indicator = document.createElement("div");

    indicator.className = "message assistant-message typing-indicator";

    indicator.id = "almefTypingIndicator";

    indicator.setAttribute("aria-label", "Almef is responding");

    indicator.setAttribute("role", "status");

    indicator.textContent = "Almef is thinking...";

    container.appendChild(indicator);

    scrollChatToBottom();

    return indicator;
}

/*
   Remove the typing indicator.
*/

function hideTypingIndicator() {
    const indicator = document.getElementById(
        "almefTypingIndicator"
    );

    if (indicator) {
        indicator.remove();
    }
}

/*
   Update the loading state.
*/

function setAlmefLoading(isLoading) {
    AlmefState.isLoading = Boolean(isLoading);

    const input = AlmefDOM.messageInput;

    if (elementExists(input)) {
        input.disabled = AlmefState.isLoading;
    }

    updateSendButtonState();
}

/* =====================================================
   27. SEND REQUEST TO BACKEND
===================================================== */

/*
   Request an AI response from the server.
*/

async function requestAssistantResponse(userMessage) {
    if (!isNetworkAvailable()) {
        showAlmefNotice(
            "You appear to be offline. Check your connection."
        );

        return;
    }

    setAlmefLoading(true);

    showTypingIndicator();

    const controller = new AbortController();

    AlmefState.abortController = controller;

    const timeoutId = setTimeout(() => {
        controller.abort();
    }, 60000);

    try {
        const response = await fetch(
            getAlmefApiUrl(),
            {
                method: "POST",
                headers: createApiHeaders(),
                body: JSON.stringify(
                    createApiPayload(userMessage)
                ),
                signal: controller.signal
            }
        );

        if (!response.ok) {
            throw new Error(
                "Server request failed: " + response.status
            );
        }

        const data = await response.json();

        const answer = extractAssistantResponse(data);

        if (!answer) {
            throw new Error(
                "The server returned an empty response."
            );
        }

        const assistantMessage = addMessageToConversation(
            "assistant",
            answer
        );

        hideTypingIndicator();

        renderMessage(assistantMessage);

    } catch (error) {
        hideTypingIndicator();

        handleApiError(error);

    } finally {
        clearTimeout(timeoutId);

        AlmefState.abortController = null;

        setAlmefLoading(false);

        if (elementExists(AlmefDOM.messageInput)) {
            AlmefDOM.messageInput.focus();
        }
    }
}

/*
   Extract the answer from supported response formats.
*/

function extractAssistantResponse(data) {
    if (typeof data === "string") {
        return data.trim();
    }

    if (!data || typeof data !== "object") {
        return "";
    }

    const answer =
        data.response ??
        data.message ??
        data.answer ??
        data.reply ??
        data.text;

    return typeof answer === "string"
        ? answer.trim()
        : "";
}

/* =====================================================
   28. CANCEL REQUEST
===================================================== */

/*
   Abort an active backend request.
*/

function cancelCurrentRequest() {
    if (AlmefState.abortController) {
        AlmefState.abortController.abort();
    }

    hideTypingIndicator();

    setAlmefLoading(false);
}

/* =====================================================
   END OF PART 8
   LINES 701–800
===================================================== */
/* =====================================================
   ALMEF JAVASCRIPT
   PART 9: ERRORS AND RESPONSE FORMATTING
   LINES 801–900
===================================================== */

/* =====================================================
   29. USER NOTIFICATIONS
===================================================== */

/*
   Display a temporary notification.
*/

function showAlmefNotice(message, duration = 3500) {
    let notice = document.getElementById("almefNotice");

    if (!notice) {
        notice = document.createElement("div");
        notice.id = "almefNotice";
        notice.className = "almef-notice";
        notice.setAttribute("role", "status");
        notice.setAttribute("aria-live", "polite");

        document.body.appendChild(notice);
    }

    notice.textContent = String(message);

    notice.classList.add("visible");

    clearTimeout(notice.hideTimer);

    notice.hideTimer = setTimeout(() => {
        notice.classList.remove("visible");
    }, duration);
}

/*
   Display an error notification.
*/

function showAlmefError(message) {
    showAlmefNotice(message, 5000);
}

/* =====================================================
   30. BACKEND ERROR HANDLING
===================================================== */

/*
   Convert request errors into helpful messages.
*/

function handleApiError(error) {
    if (error && error.name === "AbortError") {
        showAlmefError(
            "The request timed out or was cancelled."
        );

        return;
    }

    console.error("Almef API error:", error);

    const message = String(error?.message || "");

    if (
        message.includes("Failed to fetch") ||
        message.includes("NetworkError")
    ) {
        showAlmefError(
            "Could not reach the AI server. Check the connection."
        );

        return;
    }

    if (message.includes("401")) {
        showAlmefError(
            "Authentication failed. Check the server configuration."
        );

        return;
    }

    if (message.includes("403")) {
        showAlmefError(
            "The server denied this request."
        );

        return;
    }

    if (message.includes("429")) {
        showAlmefError(
            "Too many requests. Please wait and try again."
        );

        return;
    }

    showAlmefError(
        "Almef could not complete your request. Please try again."
    );
}

/* =====================================================
   31. SAFE RESPONSE FORMATTING
===================================================== */

/*
   Convert plain text into safely displayed text.
   This deliberately avoids inserting raw HTML.
*/

function formatAssistantText(text) {
    const fragment = document.createDocumentFragment();

    const lines = String(text ?? "").split("\n");

    lines.forEach((line, index) => {
        if (index > 0) {
            fragment.appendChild(
                document.createElement("br")
            );
        }

        fragment.appendChild(
            document.createTextNode(line)
        );
    });

    return fragment;
}

/*
   Update a message element with formatted text.
*/

function updateMessageContent(messageElement, text) {
    if (!elementExists(messageElement)) {
        return;
    }

    const content = messageElement.querySelector(
        ".message-content"
    );

    if (!elementExists(content)) {
        return;
    }

    content.replaceChildren(
        formatAssistantText(text)
    );
}

/*
   Find a visible message element by its identifier.
*/

function findRenderedMessage(messageId) {
    return document.querySelector(
        `[data-message-id="${CSS.escape(messageId)}"]`
    );
}

/* =====================================================
   32. COPY ASSISTANT RESPONSES
===================================================== */

/*
   Copy text to the clipboard.
*/

async function copyTextToClipboard(text) {
    try {
        if (navigator.clipboard && window.isSecureContext) {
            await navigator.clipboard.writeText(text);

            return true;
        }

        const temporary = document.createElement("textarea");

        temporary.value = text;

        temporary.setAttribute("readonly", "");

        temporary.style.position = "fixed";
        temporary.style.opacity = "0";

        document.body.appendChild(temporary);

        temporary.select();

        const successful = document.execCommand("copy");

        temporary.remove();

        return successful;

    } catch (error) {
        console.warn(
            "Almef: Clipboard operation failed.",
            error
        );

        return false;
    }
}

/*
   Copy a message and inform the user.
*/

async function copyAssistantMessage(messageId) {
    const conversation = getActiveConversation();

    if (!conversation) {
        showAlmefNotice("No active conversation.");
        return;
    }

    const message = conversation.messages.find(
        (item) => item.id === messageId
    );

    if (!message) {
        showAlmefNotice("Message not found.");
        return;
    }

    const copied = await copyTextToClipboard(
        message.content
    );

    showAlmefNotice(
        copied
            ? "Message copied."
            : "Unable to copy this message."
    );
}

/* =====================================================
   33. MESSAGE ACTION BUTTONS
===================================================== */

/*
   Create a copy button for an assistant response.
*/

function createMessageCopyButton(message) {
    const button = document.createElement("button");

    button.type = "button";

    button.className = "message-copy-button";

    button.textContent = "Copy";

    button.setAttribute(
        "aria-label",
        "Copy assistant response"
    );

    button.addEventListener("click", () => {
        copyAssistantMessage(message.id);
    });

    return button;
}

/*
   Attach copy controls to a rendered assistant message.
*/

function addMessageActions(message, element) {
    if (
        !message ||
        message.role !== "assistant" ||
        !elementExists(element)
    ) {
        return;
    }

    const actions = document.createElement("div");

    actions.className = "message-actions";

    actions.appendChild(
        createMessageCopyButton(message)
    );

    element.appendChild(actions);
}

/* =====================================================
   END OF PART 9
   LINES 801–900
===================================================== */
/* =====================================================
   ALMEF JAVASCRIPT
   PART 10: INITIALIZATION AND INTEGRATION
   LINES 901–1000
===================================================== */

/* =====================================================
   34. FINAL MESSAGE INTEGRATION
===================================================== */

/*
   Render a message with its available actions.
*/

function renderMessageWithActions(message) {
    const element = renderMessage(message);

    if (element) {
        addMessageActions(message, element);
    }

    return element;
}

/*
   Share the current conversation.
*/

async function shareCurrentConversation() {
    const conversation = getActiveConversation();

    if (!conversation || conversation.messages.length === 0) {
        showAlmefNotice("There is no conversation to share.");
        return;
    }

    const content = conversation.messages
        .map((message) => {
            const speaker = message.role === "user"
                ? "You"
                : "Almef";

            return speaker + ":\n" + message.content;
        })
        .join("\n\n");

    try {
        if (navigator.share) {
            await navigator.share({
                title: conversation.title || "Almef conversation",
                text: content
            });
        } else {
            const copied = await copyTextToClipboard(content);

            showAlmefNotice(
                copied
                    ? "Conversation copied for sharing."
                    : "Unable to share this conversation."
            );
        }
    } catch (error) {
        if (error.name !== "AbortError") {
            showAlmefNotice("Sharing could not be completed.");
        }
    }
}

/* =====================================================
   35. APPLICATION EVENT LISTENERS
===================================================== */

/*
   Connect sidebar and navigation controls.
*/

function initializeNavigationEvents() {
    AlmefDOM.openSidebar?.addEventListener(
        "click",
        toggleAlmefSidebar
    );

    AlmefDOM.closeSidebar?.addEventListener(
        "click",
        closeAlmefSidebar
    );

    AlmefDOM.sidebarOverlay?.addEventListener(
        "click",
        closeAlmefSidebar
    );

    AlmefDOM.newChat?.addEventListener(
        "click",
        startNewChat
    );

    AlmefDOM.navItems.forEach((item) => {
        item.addEventListener(
            "click",
            handleNavigationClick
        );
    });
}

/*
   Connect composer and keyboard controls.
*/

function initializeComposerEvents() {
    AlmefDOM.messageInput?.addEventListener(
        "keydown",
        handleComposerKeydown
    );

    AlmefDOM.messageInput?.addEventListener(
        "input",
        handleComposerInput
    );

    AlmefDOM.sendButton?.addEventListener(
        "click",
        submitCurrentMessage
    );

    document.addEventListener(
        "keydown",
        handleAlmefKeyboardShortcuts
    );
}

/*
   Connect theme and About controls.
*/

function initializeSettingsEvents() {
    AlmefDOM.themeToggle?.addEventListener(
        "click",
        toggleAlmefTheme
    );

    AlmefDOM.aboutButton?.addEventListener(
        "click",
        openAboutDialog
    );

    AlmefDOM.closeAbout?.addEventListener(
        "click",
        closeAboutDialog
    );

    AlmefDOM.aboutDialog?.addEventListener(
        "click",
        handleAboutDialogClick
    );

    AlmefDOM.shareButton?.addEventListener(
        "click",
        shareCurrentConversation
    );
}

/*
   Connect voice and image controls.
*/

function initializeMediaEvents() {
    AlmefDOM.voiceButton?.addEventListener(
        "click",
        toggleVoiceInput
    );

    AlmefDOM.attachButton?.addEventListener(
        "click",
        openImagePicker
    );

    AlmefDOM.imageInput?.addEventListener(
        "change",
        handleImageSelection
    );
}

/* =====================================================
   36. RESTORE APPLICATION STATE
===================================================== */

/*
   Restore the last conversation and preferences.
*/

function initializeConversationState() {
    loadConversations();

    const conversation = getActiveConversation();

    if (conversation) {
        restoreActiveConversation();
    } else {
        showWelcomeScreen();
    }

    renderConversationHistory();
}

/*
   Connect all application event listeners.
*/

function initializeAlmefEvents() {
    initializeNavigationEvents();

    initializeComposerEvents();

    initializeSettingsEvents();

    initializeMediaEvents();

    window.addEventListener("resize", () => {
        if (!isMobileScreen()) {
            closeAlmefSidebar();
        }

        resizeMessageInput();
    });
}

/* =====================================================
   37. START APPLICATION
===================================================== */

/*
   Initialize Almef when the document is ready.
*/

function initializeAlmef() {
    configureDocumentMetadata();

    updateBrowserTitle();

    initializeAlmefTheme();

    initializeConversationState();

    initializeAlmefEvents();

    updateSendButtonState();

    updateVoiceButtonState();

    almefLog(
        "Almef initialized successfully.",
        getAlmefSettings()
    );
}

/*
   Start once the HTML document has loaded.
*/

if (document.readyState === "loading") {
    document.addEventListener(
        "DOMContentLoaded",
        initializeAlmef,
        { once: true }
    );
} else {
    initializeAlmef();
}

/* =====================================================
   38. APPLICATION READY
===================================================== */

window.Almef = {
    initialize: initializeAlmef,
    newChat: startNewChat,
    sendMessage: submitCurrentMessage,
    openConversation: openConversation,
    deleteConversation: deleteConversation,
    switchView: switchAlmefView,
    toggleTheme: toggleAlmefTheme,
    getSettings: getAlmefSettings
};

/* =====================================================
   END OF PART 10
   LINES 901–1000
===================================================== */